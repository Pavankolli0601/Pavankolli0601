# path: portfolio/README.md
# Data Engineering Portfolio

This repo groups small, focused examples used to demonstrate data engineering skills. Keep each directory self‑contained with a short README and runnable example data/scripts.

## Contents
- `airflow-dag/` — S3 → Snowflake ELT DAG
- `data-quality-framework/` — Reconciliation & schema checks
- `dbt_demo/` — Example model & tests
- `kafka-streaming/` — Minimal producer/consumer
- `snowflake/` — SQL objects, RBAC, masking
- `terraform/` — IaC for S3 + IAM (starter)
