# path: portfolio/airflow-dag/dags/s3_to_snowflake.py
from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.python import PythonOperator

# IMPORTANT: Replace placeholders with your Snowflake creds and S3 path.
def load_to_snowflake(**context):
    import os
    import snowflake.connector
    import pandas as pd

    # why: Keep demo self-contained; in real-world use externalized secrets.
    conn = snowflake.connector.connect(
        user=os.getenv("SNOWFLAKE_USER", "demo_user"),
        password=os.getenv("SNOWFLAKE_PASSWORD", "demo_pass"),
        account=os.getenv("SNOWFLAKE_ACCOUNT", "demo_account"),
        warehouse=os.getenv("SNOWFLAKE_WAREHOUSE", "COMPUTE_WH"),
        database=os.getenv("SNOWFLAKE_DATABASE", "DEMO_DB"),
        schema=os.getenv("SNOWFLAKE_SCHEMA", "PUBLIC"),
    )

    # Read sample CSV and load into Snowflake using pandas write_pandas if available.
    sample_csv = context["params"].get("sample_csv", "/usr/local/airflow/dags/sample.csv")
    df = pd.read_csv(sample_csv)
    cur = conn.cursor()
    try:
        cur.execute("CREATE OR REPLACE TABLE PUBLIC.ORDERS_DEMO (id INT, amount NUMBER, ts TIMESTAMP)")
        try:
            from snowflake.connector.pandas_tools import write_pandas
            write_pandas(conn, df, "ORDERS_DEMO")
        except Exception:
            rows = [tuple(x) for x in df.to_numpy()]
            cur.executemany("INSERT INTO PUBLIC.ORDERS_DEMO (id, amount, ts) VALUES (%s, %s, %s)", rows)
    finally:
        cur.close()
        conn.close()

default_args = {
    "owner": "pavan",
    "depends_on_past": False,
    "retries": 1,
    "retry_delay": timedelta(minutes=5),
}

with DAG(
    dag_id="s3_to_snowflake_demo",
    start_date=datetime(2024, 1, 1),
    schedule_interval="@daily",
    catchup=False,
    default_args=default_args,
    tags=["demo", "snowflake", "s3"],
) as dag:
    load = PythonOperator(
        task_id="load_to_snowflake",
        python_callable=load_to_snowflake,
        params={"sample_csv": "/usr/local/airflow/dags/sample.csv"},
    )
    load
