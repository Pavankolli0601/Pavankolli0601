# path: portfolio/dbt_demo/models/stg_orders.sql
-- WHY: Keep transformations declarative; enable tests & lineage.
with src as (
    select * from {{ source('raw', 'orders') }}
)
select
    cast(id as int) as order_id,
    cast(amount as decimal(10,2)) as amount,
    cast(ts as timestamp) as order_ts
from src
where amount is not null
