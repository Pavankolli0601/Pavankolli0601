# path: portfolio/snowflake/warehouse.sql
-- WHY: Demonstrates RBAC + masking policy basics.
create or replace warehouse de_wh with warehouse_size='XSMALL' auto_suspend=60 auto_resume=true;
create or replace role de_reader;
grant usage on warehouse de_wh to role de_reader;

create or replace masking policy mask_email as (val string) returns string ->
  case
    when current_role() in ('DE_READER') then regexp_replace(val,'(.*)@(.*)','***@\2')
    else val
  end;

create or replace table users_demo (id int, email string);
alter table users_demo modify column email set masking policy mask_email;
