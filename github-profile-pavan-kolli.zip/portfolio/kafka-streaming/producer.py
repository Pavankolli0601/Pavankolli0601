# path: portfolio/kafka-streaming/producer.py
from kafka import KafkaProducer
import json, time, random

def main():
    producer = KafkaProducer(
        bootstrap_servers=["localhost:9092"],
        value_serializer=lambda v: json.dumps(v).encode("utf-8"),
    )
    while True:
        event = {"id": random.randint(1, 1000), "amount": round(random.random() * 100, 2)}
        producer.send("orders", value=event)
        producer.flush()
        time.sleep(1)

if __name__ == "__main__":
    main()
