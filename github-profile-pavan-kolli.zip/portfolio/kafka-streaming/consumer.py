# path: portfolio/kafka-streaming/consumer.py
from kafka import KafkaConsumer
import json

def main():
    consumer = KafkaConsumer(
        "orders",
        bootstrap_servers=["localhost:9092"],
        value_deserializer=lambda b: json.loads(b.decode("utf-8")),
        auto_offset_reset="earliest",
        enable_auto_commit=True,
        group_id="orders-consumers",
    )
    for msg in consumer:
        print("event:", msg.value)

if __name__ == "__main__":
    main()
