# path: portfolio/data-quality-framework/main.py
'''
Minimal reconciliation & schema validation tool.
WHY: Shows approach for accuracy, auditability, and early failure detection.
'''
from __future__ import annotations
import argparse, json, csv, sys
from typing import Dict, List, Any

def read_csv_counts(path: str) -> int:
    with open(path, newline="") as f:
        return sum(1 for _ in csv.reader(f)) - 1  # minus header

def validate_schema(row: Dict[str, Any], required_fields: List[str]) -> List[str]:
    return [k for k in required_fields if k not in row or row[k] in (None, "")]

def main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument("--source", required=True)
    p.add_argument("--target", required=True)
    p.add_argument("--schema", required=True, help="JSON array of required field names")
    args = p.parse_args()

    source_count = read_csv_counts(args.source)
    target_count = read_csv_counts(args.target)
    if source_count != target_count:
        print(json.dumps({"status": "FAIL", "reason": "COUNT_MISMATCH", "source": source_count, "target": target_count}))
        return 2

    required = json.loads(args.schema)
    with open(args.target, newline="") as f:
        reader = csv.DictReader(f)
        for i, row in enumerate(reader, 1):
            missing = validate_schema(row, required)
            if missing:
                print(json.dumps({"status": "FAIL", "reason": "SCHEMA_MISSING", "row": i, "missing": missing}))
                return 3

    print(json.dumps({"status": "OK", "rows": target_count}))
    return 0

if __name__ == "__main__":
    sys.exit(main())
